.. ecomap documentation master file, created by
   sphinx-quickstart on Wed Dec 16 14:22:34 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Ecomap.org documentation!
====================================

.. image:: _static/ecomap_logo.jpg

Read the docs
-------------

.. toctree::
   :maxdepth: 3

   flask


About Ecomap
------------

.. toctree::
   :maxdepth: 2

   about


View Sourcecode
---------------


.. toctree::
   :maxdepth: 2

   sourcecode
   guide

