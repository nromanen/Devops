About Project
=============

- **ecomap.org** is web-resource, main purposes of which are collecting information
- about ecologilcal problems of Ukraine & organise interaction between reporters and Ministry of Environment Ukraine;
- **ecomap.org** is non-profit social project;
- The old version of the project is available with url: www.ecomap.org
- The main goal for our team is creating new project from scratch;


Developer info
--------------

SoftServe LV-164 team:
    - Liubomyr Halamaha - *teacher*
    - Yuriy Luktey - *expert*

    - Andrii Piratovskyi
    - Illya Pavlovskyi
    - Gamolya Vlad
    - Petro Lozhkin
    - Vadym Padalko

