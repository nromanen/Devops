INSERT INTO `user` (first_name, last_name, nickname, email, password)
VALUES ('admin', 'admin', 'admin', 'admin@ecomap.com', '1955bbb030591717a09f6ddec6807077');
INSERT INTO `user` (first_name, last_name, nickname, email, password)
VALUES ('anonymous', 'anonymous', 'anonymous', 'anonymous@ecomap.com', '1955bbb030591717a09f6ddec6807077');