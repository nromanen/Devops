insert into subscription (problem_id, user_id, date_subscriptions, severity) values (2, 1, 17000002, '2');
insert into subscription (problem_id, user_id, date_subscriptions, severity) values (1, 1, 2, '1');
insert into subscription (problem_id, user_id, date_subscriptions, severity) values (5, 1, 1230000, '5');
