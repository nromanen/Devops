INSERT INTO role (name) VALUES ('admin');
INSERT INTO role (name) VALUES ('user');
INSERT INTO role (name) VALUES ('moderator');
