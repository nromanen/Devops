var gulp = require('gulp');

gulp.task('build', ['html', 'images', 'fonts', 'sounds']);
